import json

def max_revenue(movies):

    result = None
    title = None
    for idx, movie in enumerate(movies) :
        movie_id = movie.get('id')
        movie_json = open(f'data/movies/{movie_id}.json', encoding='utf-8')
        movie_dict = json.load(movie_json)
        if idx == 0 :
            result = movie_dict.get('revenue')
            title = movie_dict.get('title')
        elif movie_dict.get('revenue') > result:
              result = movie_dict.get('revenue')
              title = movie_dict.get ('title')
    return title


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    movies_json = open('data/movies.json', encoding='utf-8')
    movies_list = json.load(movies_json)
    
    print(max_revenue(movies_list))



