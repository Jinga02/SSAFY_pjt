import json


def dec_movies(movies):
    movie_list = []
    for movie in movies:
        movie_id = movie.get('id')
        movie_json = open(f'data/movies/{movie_id}.json', encoding='utf-8')        
        movie_dict = json.load(movie_json)
        release_date = movie_dict.get('release_date')
        _, month, _ = release_date.split('-')
        if month == '12' :
            movie_list.append(movie_dict.get('title'))
    return movie_list

# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    movies_json = open('data/movies.json', encoding='utf-8')
    movies_list = json.load(movies_json)
    
    print(dec_movies(movies_list))
	